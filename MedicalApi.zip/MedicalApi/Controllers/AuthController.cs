﻿using MedicalApi.Interfaces;
using MedicalApi.Models;
using MedicalAPI.Helpers;
using MedicalAPI.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace MedicalAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _service;
        private readonly IWebHostEnvironment _env; // ✅ this gives access to wwwroot folder

        public AuthController(IAuthService service, IWebHostEnvironment env)
        {
            _service = service;
            _env = env;
        }

        [HttpPost("signup")]
        public async Task<IActionResult> SignUp([FromBody] UserModel1 model)
        {
            var result = await _service.Register(model);
            return Ok(new { message = result });
        }
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] UserModel model)
        {
            if (model == null || string.IsNullOrEmpty(model.Email) || string.IsNullOrEmpty(model.Password))
            {
                return BadRequest(new { success = false, message = "Email and password are required!" });
            }


            var result = await _service.Login(model.Email, model.Password);

            if (result.success)
                return Ok(result);
            else
                return Unauthorized(result);
        }

        [HttpGet("GetAllUser")]
        public async Task<IActionResult> GetAllUser(string? email = null)
        {
            try
            {
                // Fetch data from service
                var users = _service.GetAllUser(email);

                if (users == null)
                {
                    return NotFound(new { success = false, message = "No users found!" });
                }

                string msg = string.IsNullOrEmpty(email)
                    ? "All users retrieved successfully!"
                    : "User retrieved successfully!";

                return Ok(new
                {
                    success = true,
                    message = msg,
                    data = users
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    success = false,
                    message = "An error occurred while retrieving users.",
                    error = ex.Message
                });
            }
        }

        [HttpPost("UploadProfileImage")]
        public IActionResult UploadProfileImage([FromForm] int UserId, [FromForm] IFormFile file)
        {
            if (file == null || file.Length == 0)
                return BadRequest(new { success = false, message = "No file selected." });

            try
            {
                byte[] imageBytes;
                using (var ms = new MemoryStream())
                {
                    file.CopyTo(ms);
                    imageBytes = ms.ToArray();
                }

                // Save to database
                bool result = _service.UpdateUserProfileImage(UserId, imageBytes);

                if (result)
                    return Ok(new { success = true, message = "Profile image updated successfully!" });
                else
                    return BadRequest(new { success = false, message = "Failed to save image in database." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = "Error: " + ex.Message });
            }
        }
        [HttpDelete("DeleteMedicalRecord/{userId}")]
        public IActionResult DeleteMedicalRecord(int userId)
        {
            try
            {
                var result = _service.DeleteMedicalRecord(userId);

                if (result)
                    return Ok(new { success = true, message = "All medical records deleted for this user." });
                else
                    return Ok(new { success = false, message = "No records found for this user." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = $"Error: {ex.Message}" });
            }
        }




        [HttpPost("AddMedicalRecord")]
        public async Task<IActionResult> AddMedicalRecord([FromForm] MedicalRecordModel model, IFormFile file)
        {
            if (file == null || file.Length == 0)
                return BadRequest(new { success = false, message = "File not selected." });

            try
            {
                string base64String = "";

                // ✅ 1. Convert uploaded file to Base64 string
                using (var ms = new MemoryStream())
                {
                    await file.CopyToAsync(ms);
                    byte[] fileBytes = ms.ToArray();
                    base64String = Convert.ToBase64String(fileBytes);
                }

               
                string uniqueFileName = file.FileName;
               

                // ✅ 3. Prepare data model for DB insert
                var record = new MedicalRecordModel3
                {
                    UserId = model.UserId,
                    FileType = Path.GetExtension(file.FileName)?.TrimStart('.'),
                    MFileType = model.FileType,
                    MFileName = model.FileName,
                    FileName = uniqueFileName,
                    FilePath = "",
                    FileData = base64String, 
                    CreatedDate = DateTime.Now,
                    CreatedBy = model.CreatedBy ?? "System"
                };

                // ✅ 4. Insert into DB
                bool isInserted = _service.AddMedicalRecord(record);

                if (isInserted)
                {
                    return Ok(new
                    {
                        success = true,
                        message = "Medical record saved successfully.",
                        record.FileName,
                        record.FileType,
                        record.FilePath
                    });
                }
                else
                {
                    return BadRequest(new { success = false, message = "Database insert failed." });
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new { success = false, message = "Error: " + ex.Message });
            }
        }

        [HttpGet("GetMedicalRecordsByUser/{userId}")]
        public IActionResult GetMedicalRecordsByUser(int userId)
        {
            try
            {
                var records = _service.GetMedicalRecordsByUserId(userId);
                return Ok(new { success = true, data = records });
            }
            catch (Exception ex)
            {
                return BadRequest(new { success = false, message = ex.Message });
            }
        }

        [HttpDelete("DeleteMedicalRecordById/{recordId}")]
        public IActionResult DeleteMedicalRecordById(int recordId, int userId)
        {
            try
            {
                if (recordId <= 0 || userId <= 0)
                {
                    return BadRequest(new { success = false, message = "Invalid record or user ID!" });
                }

                bool isDeleted = _service.DeleteMedicalRecordById(recordId, userId);

                if (isDeleted)
                    return Ok(new { success = true, message = "Medical record deleted successfully." });
                else
                    return NotFound(new { success = false, message = "No record found or deletion failed." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

    }
}