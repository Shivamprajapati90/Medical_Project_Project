﻿using Microsoft.AspNetCore.Mvc;

namespace MedicalApi.Controllers
{
    public class RecordsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
