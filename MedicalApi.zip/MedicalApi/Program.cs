﻿using MedicalApi.Interfaces;
using MedicalAPI.Helpers;
using MedicalAPI.Services;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);


builder.Configuration
       .SetBasePath(Directory.GetCurrentDirectory())
       .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
       .AddEnvironmentVariables();


builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.PropertyNamingPolicy = null;
    });


builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "Medical API",
        Version = "v1",
        Description = "Medical Record Management API with ADO.NET and AWS Token"
    });
});


builder.Services.AddScoped<_help>();
builder.Services.AddScoped<IAuthService, AuthService>();


builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
        policy
            .AllowAnyOrigin()        
            .AllowAnyMethod()       
            .AllowAnyHeader()        
            .WithExposedHeaders("Content-Disposition")); 
});

var app = builder.Build();


if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(options =>
    {
        options.SwaggerEndpoint("/swagger/v1/swagger.json", "Medical API v1");
        options.RoutePrefix = string.Empty; 
    });
}

app.UseHttpsRedirection();


app.UseCors("AllowAll");

app.UseAuthorization();


app.MapControllers();


app.Run();
