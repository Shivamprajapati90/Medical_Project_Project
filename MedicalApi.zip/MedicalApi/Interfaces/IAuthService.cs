﻿using MedicalApi.Models;

namespace MedicalApi.Interfaces
{
    public interface IAuthService
    {
        Task<ResponseModel> Register(UserModel1 model);
         Task<LoginResponse> Login(string email, string password);
        object GetAllUser(string email);
        bool AddMedicalRecord(MedicalRecordModel3 record);
        bool UpdateUserProfileImage(int userId, byte[] imageBytes);
        object GetMedicalRecordsByUserId(int userId);
        bool DeleteMedicalRecord(int id);
        bool DeleteMedicalRecordById(int recordId, int userId);
    }
}
