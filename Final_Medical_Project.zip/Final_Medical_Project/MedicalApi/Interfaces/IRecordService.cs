﻿namespace MedicalApi.Interfaces
{
    public class IRecordService
    {
    }
}
