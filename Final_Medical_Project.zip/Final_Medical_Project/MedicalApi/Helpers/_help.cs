﻿using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;

namespace MedicalAPI.Helpers
{
    public class _help
    {
        private readonly IConfiguration _configuration;

        public _help(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        // ✅ To get connection easily
        public SqlConnection GetConnection()
        {
            return new SqlConnection(_configuration.GetConnectionString("MyConn"));
        }

        // ✅ Optional shortcut if you just want connection string
        public string GetConn()
        {
            return _configuration.GetConnectionString("MyConn");
        }
    }
}


//using System;
//using System.Data.SqlClient;
//using Microsoft.Extensions.Configuration;
//using Amazon.SecurityToken;
//using Amazon.SecurityToken.Model;

//namespace MedicalAPI.Helpers
//{
//    public class _help
//    {
//        private readonly IConfiguration _config;
//        public _help(IConfiguration config)
//        {
//            _config = config;
//        }

//        // ✅ Get SQL Connection
//        public SqlConnection GetConnection()
//        {
//            string connStr = _config.GetConnectionString("MyConn");
//            return new SqlConnection(connStr);
//        }

//        // ✅ Generate AWS Token (Temporary)
//        public string GenerateAWSToken()
//        {
//            var accessKey = _config["AWS:AccessKey"];
//            var secretKey = _config["AWS:SecretKey"];
//            var region = _config["AWS:Region"];

//            try
//            {
//                using var stsClient = new AmazonSecurityTokenServiceClient(accessKey, secretKey, Amazon.RegionEndpoint.GetBySystemName(region));
//                var request = new GetSessionTokenRequest { DurationSeconds = 3600 };
//                var response = stsClient.GetSessionTokenAsync(request).Result;
//                return response.Credentials.SessionToken;
//            }
//            catch (Exception ex)
//            {
//                return "AWS Token Error: " + ex.Message;
//            }
//        }
//    }
//}
