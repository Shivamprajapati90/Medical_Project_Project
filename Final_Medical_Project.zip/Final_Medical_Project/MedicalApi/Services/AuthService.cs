﻿using Amazon;
using Amazon.SecurityToken;
using Amazon.SecurityToken.Model;
using MedicalApi.Interfaces;
using MedicalApi.Models;
using MedicalAPI.Helpers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace MedicalAPI.Services
{
    public class AuthService : IAuthService
    {
        private readonly _help _help;
        private readonly IConfiguration _config;

        public AuthService(_help help, IConfiguration config)
        {
            _help = help;
            _config = config;
        }

        public async Task<ResponseModel> Register(UserModel1 model)
        {
            using (SqlConnection con = _help.GetConnection())
            {
                await con.OpenAsync();

                using (SqlCommand cmd = new SqlCommand("sp_InsertUserMaster", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@FullName", model.FullName);
                    cmd.Parameters.AddWithValue("@Email", model.Email);
                    cmd.Parameters.AddWithValue("@Gender", model.Gender);
                    cmd.Parameters.AddWithValue("@Phone", model.Phone);
                    cmd.Parameters.AddWithValue("@Password", model.Password);

                    using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            bool isSuccess = reader.GetInt32(0) == 1;
                            string message = reader.GetString(1);

                            return new ResponseModel
                            {
                                success = isSuccess,
                                message = message
                            };
                        }
                    }
                }
            }

            // In case no data is returned from stored procedure
            return new ResponseModel
            {
                success = false,
                message = "No response from database."
            };
        }


        public async Task<LoginResponse> Login(string email, string password)
        {
            try
            {
                using (SqlConnection conn = _help.GetConnection())
                {
                    await conn.OpenAsync();

                    using (SqlCommand cmd = new SqlCommand("sp_LoginUser", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Email", email);
                        cmd.Parameters.AddWithValue("@Password", password);

                        int result = Convert.ToInt32(await cmd.ExecuteScalarAsync());

                        if (result == 0)
                        {
                            return new LoginResponse
                            {
                                success = false,
                                message = "Login failed! Invalid email or password."
                            };
                        }
                    }
                }


                // 🔹 AWS Token generation
                string awsAccessKey = _config["AWS:AccessKey"];
                string token;

                if (string.IsNullOrEmpty(awsAccessKey) ||
                    awsAccessKey == "YOUR_AWS_ACCESS_KEY" ||
                    awsAccessKey == "TEMP_ACCESS_KEY")
                {
                    token = "FAKE_AWS_" + Guid.NewGuid().ToString("N");
                }
                else
                {
                    string awsSecretKey = _config["AWS:SecretKey"];
                    string region = _config["AWS:Region"];

                    using (var stsClient = new AmazonSecurityTokenServiceClient(
                               awsAccessKey,
                               awsSecretKey,
                               RegionEndpoint.GetBySystemName(region)))
                    {
                        var request = new GetSessionTokenRequest
                        {
                            DurationSeconds = 3600
                        };

                        var response = await stsClient.GetSessionTokenAsync(request);
                        token = response.Credentials.SessionToken;
                    }
                }

                // ✅ Success response
                return new LoginResponse
                {
                    success = true,
                    message = "Login successful!",
                    token = token
                };
            }
            catch (Exception ex)
            {
                // ⚠ Handle unexpected errors
                return new LoginResponse
                {
                    success = false,
                    message = "An error occurred: " + ex.Message
                };
            }
        }

        public object GetAllUser(string email)
        {
            if (string.IsNullOrEmpty(email))
                return null;

            UserModel user = null;

            using (SqlConnection con = _help.GetConnection())
            {
                using (SqlCommand cmd = new SqlCommand("sp_GetAllUser", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Email", email);

                    con.Open();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            user = new UserModel
                            {
                                Id = Convert.ToInt32(dr["Id"]),
                                FullName = dr["FullName"].ToString(),
                                Email = dr["Email"].ToString(),
                                Gender = dr["Gender"].ToString(),
                                Phone = dr["Phone"].ToString(),
                                Password = dr["Password"].ToString(),
                                ProfileImage = dr["ProfileImage"] == DBNull.Value ? null : (byte[])dr["ProfileImage"]
                            };
                        }
                    }
                }
            }

            return user;
        }

        public bool AddMedicalRecord(MedicalRecordModel3 record)
        {
            try
            {
                using (SqlConnection con = _help.GetConnection())
                using (SqlCommand cmd = new SqlCommand("sp_AddMedicalRecord", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@UserId", record.UserId);
                    cmd.Parameters.AddWithValue("@FileType", (object?)record.FileType ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@FileName", record.FileName);
                    cmd.Parameters.AddWithValue("@FilePath", (object?)record.FilePath ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@FileData", (object?)record.FileData ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@CreatedDate", record.CreatedDate);
                    cmd.Parameters.AddWithValue("@CreatedBy", record.CreatedBy);
                    cmd.Parameters.AddWithValue("@MFileType", (object?)record.MFileType ?? DBNull.Value); // ✅ Added
                    cmd.Parameters.AddWithValue("@MFileName", (object?)record.MFileName ?? DBNull.Value); // ✅ Added

                    var outputParam = new SqlParameter("@NewRecordId", SqlDbType.Int)
                    {
                        Direction = ParameterDirection.Output
                    };
                    cmd.Parameters.Add(outputParam);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    int newId = Convert.ToInt32(outputParam.Value);

                    return newId > 0; // ✅ true if inserted successfully
                }
            }
            catch (Exception ex)
            {
                // Log exception (optional)
                Console.WriteLine("Error adding medical record: " + ex.Message);
                return false;
            }
        }


        public bool UpdateUserProfileImage(int userId, byte[] imageBytes)
        {
            bool isUpdated = false;

            using (SqlConnection conn = _help.GetConnection())
            {
                string query = "UPDATE [UserMaster] SET ProfileImage = @ProfileImage WHERE Id = @UserId";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.Add("@ProfileImage", SqlDbType.VarBinary).Value = imageBytes;
                    cmd.Parameters.AddWithValue("@UserId", userId);

                    conn.Open();
                    int rows = cmd.ExecuteNonQuery();
                    isUpdated = rows > 0;
                }
            }

            return isUpdated;
        }
        public object GetMedicalRecordsByUserId(int userId)
        {
            var records = new List<object>();

            using (SqlConnection con = _help.GetConnection())
            {
                using (SqlCommand cmd = new SqlCommand("GetMedicalRecordsByUserId", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@UserId", userId);
                    con.Open();

                    using (var dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            string MfileType = dr["MFileType"]?.ToString() ?? "";
                            string MFileName = dr["MFileName"]?.ToString() ?? "";
                            string fileType = dr["FileType"]?.ToString() ?? "";
                            string fileData = dr["FileData"]?.ToString() ?? "";
                            string mimeType = "application/octet-stream";

                            // Detect MIME type for preview
                            if (fileType.Contains("jpg", StringComparison.OrdinalIgnoreCase) ||
                                fileType.Contains("jpeg", StringComparison.OrdinalIgnoreCase))
                                mimeType = "image/jpeg";
                            else if (fileType.Contains("png", StringComparison.OrdinalIgnoreCase))
                                mimeType = "image/png";
                            else if (fileType.Contains("pdf", StringComparison.OrdinalIgnoreCase))
                                mimeType = "application/pdf";
                            else if (fileType.Contains("bmp", StringComparison.OrdinalIgnoreCase))
                                mimeType = "image/bmp";
                            else if (fileType.Contains("gif", StringComparison.OrdinalIgnoreCase))
                                mimeType = "image/gif";

                            records.Add(new
                            {
                                Id = Convert.ToInt32(dr["Id"]),
                                FileName = dr["FileName"]?.ToString(),
                                FileType = fileType,
                                FileData = fileData, // Base64 string
                                MimeType = mimeType,
                                MFileType = MfileType,
                                MFileName = MFileName
                            });
                        }
                    }
                }
            }

            return records;
        }


        public bool DeleteMedicalRecord(int id)
        {
            try
            {
                using (SqlConnection conn = _help.GetConnection())
                {
                    conn.Open();

                    string query = "DELETE FROM MedicalRecords WHERE UserId = @RecordId";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@RecordId", id);

                        int rows = cmd.ExecuteNonQuery();
                        return rows > 0; // true = deleted successfully, false = not found
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error deleting record: " + ex.Message);
                return false;
            }
        }

        public bool DeleteMedicalRecordById(int recordId, int userId)
        {
            try
            {
                using (SqlConnection conn = _help.GetConnection())
                {
                    conn.Open();

                    string query = "DELETE FROM MedicalRecords WHERE UserId = @userId And Id=@recordId";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@userId", userId);
                        cmd.Parameters.AddWithValue("@recordId", recordId);
                        int rows = cmd.ExecuteNonQuery();
                        return rows > 0; // true = deleted successfully, false = not found
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error deleting record: " + ex.Message);
                return false;
            }
        }
    }

}

