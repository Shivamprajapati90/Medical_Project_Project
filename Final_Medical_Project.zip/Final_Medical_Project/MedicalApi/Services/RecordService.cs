﻿namespace MedicalApi.Services
{
    public class RecordService
    {
    }
}
