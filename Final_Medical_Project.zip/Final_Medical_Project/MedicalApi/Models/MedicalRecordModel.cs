﻿namespace MedicalApi.Models
{
    public class MedicalRecordModel
    {
        public int? Id { get; set; }
        public int? UserId { get; set; }
        public string? FileType { get; set; }
        public string? FileName { get; set; }
        public string? FilePath { get; set; }
        public string? FileData { get; set; }  // <-- base64 string

        public DateTime? CreatedDate { get; set; }
        public string? CreatedBy { get; set; }
    }
    public class MedicalRecordModel3
    {
        public int? Id { get; set; }
        public int? UserId { get; set; }
        public string? FileType { get; set; }
        public string? FileName { get; set; }
        public string? FilePath { get; set; }
        public string? FileData { get; set; }  // <-- base64 string
        public string? MFileType { get; set; }
        public string? MFileName { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string? CreatedBy { get; set; }
    }
}
