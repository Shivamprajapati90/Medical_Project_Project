﻿using Medical.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Diagnostics;
using System.Net.Http;
using System.Numerics;
using System.Reflection;
using System.Text;

namespace Medical.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    private readonly IHttpClientFactory _httpClientFactory;

    public HomeController(ILogger<HomeController> logger, IHttpClientFactory httpClientFactory)
    {
        _logger = logger;
        _httpClientFactory = httpClientFactory;

    }

    public IActionResult Index()
    {
        return View();
    }
    public IActionResult Login()
    {
        return View();
    }
    [HttpPost]
    public async Task<IActionResult> Login(string Email, string Password)
    {
        var client = _httpClientFactory.CreateClient();

        var userData = new
        {
            FullName="",
            Email = Email,
            Gender="",
            Phone="",
            Password = Password
        };

        var json = JsonConvert.SerializeObject(userData);
        var content = new StringContent(json, Encoding.UTF8, "application/json");

        var response = await client.PostAsync("https://localhost:7114/api/Auth/login", content);
        var result = await response.Content.ReadAsStringAsync();

        if (response.IsSuccessStatusCode)
        {
            // Deserialize the API JSON (example: success, message, token)
            dynamic apiResult = JsonConvert.DeserializeObject(result);

            bool success = apiResult.success;
            string message = apiResult.message;
            string token = apiResult.token ?? "";

            if (success)
            {
                // ✅ Save session if login successful
                HttpContext.Session.SetString("Email", Email);
                HttpContext.Session.SetString("Token", token);

                // Return same clean JSON as API
                return Json(new
                {
                    success = true,
                    message,
                    token
                });
            }
            else
            {
                // Login failed
                return Json(new
                {
                    success = false,
                    message
                });
            }
        }
        else
        {
            // API itself failed (bad request, etc.)
            return Json(new
            {
                success = false,
                message = "Login request failed!",
                error = result
            });
        }
    }

    [HttpPost]
    public async Task<IActionResult> Signup([FromBody] UserModel1 model)
    {
        if (model == null)
            return BadRequest(new { success = false, message = "Invalid request data" });

        try
        {
            var client = _httpClientFactory.CreateClient();
            var json = JsonConvert.SerializeObject(model);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            // Call your API
            var response = await client.PostAsync("https://localhost:7114/api/Auth/signup", content);
            var responseBody = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                return Ok(new { success = true, message = "Account created successfully!", data = responseBody });
            }
            else
            {
                return BadRequest(new { success = false, message = responseBody });
            }
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { success = false, message = ex.Message });
        }
    }
    
    public IActionResult Logout()
    {
        HttpContext.Session.Remove("Email");
        HttpContext.Session.Remove("Token");
        //HttpContext.Session.Clear();
        return RedirectToAction("Login");
    }
    [HttpPost]
    public async Task<IActionResult> ForgotPassword([FromBody] UserModel model)
    {
        if (string.IsNullOrEmpty(model.Email))
            return BadRequest(new { success = false, message = "Email is required" });

        try
        {
            // 🔹 Example: Call API or database to send reset link
            // (You can integrate your email service or token-based reset system here)

            // Example: success message
            return Ok(new { success = true, message = "Password reset link sent successfully!" });
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { success = false, message = ex.Message });
        }
    }
    public async Task<IActionResult> Dashboard()
    {
        // ✅ 1. Get session values
        var email = HttpContext.Session.GetString("Email");
        var token = HttpContext.Session.GetString("Token");

        if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(token))
        {
            // Redirect to Login if session missing
            return RedirectToAction("Login", "Home");
        }

        // ✅ 2. Prepare HttpClient
        var client = new HttpClient();
        client.DefaultRequestHeaders.Accept.Clear();
        client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

        // ✅ 3. Build API URL
        string apiUrl = $"https://localhost:7114/api/Auth/GetAllUser?email={Uri.EscapeDataString(email)}";

        try
        {
            // ✅ 4. Call API
            var response = await client.GetAsync(apiUrl);

            if (response.IsSuccessStatusCode)
            {
                // ✅ 5. Parse JSON data
                var json = await response.Content.ReadAsStringAsync();

                // Deserialize to dynamic or your UserModel
                var result = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(json);

                // Optional: extract user object (depends on API structure)
                var userData = result?.data;
               
                // ✅ 6. Pass data to view
                return View(userData);
            }
            else
            {
                ViewBag.Error = "Failed to retrieve user data from API.";
                return View(null);
            }
        }
        catch (Exception ex)
        {
            ViewBag.Error = "Error: " + ex.Message;
            return View(null);
        }
    }
    [HttpPost]
    public async Task<IActionResult> UploadProfileImage(int UserId, IFormFile file)
    {
        if (file == null || file.Length == 0)
            return Json(new { success = false, message = "Please select a file." });

        try
        {
            using (var client = new HttpClient())
            {
                client.Timeout = TimeSpan.FromMinutes(2);

                using (var formData = new MultipartFormDataContent())
                {
                    formData.Add(new StringContent(UserId.ToString()), "UserId");

                    var fileStreamContent = new StreamContent(file.OpenReadStream());
                    fileStreamContent.Headers.ContentType =
                        new System.Net.Http.Headers.MediaTypeHeaderValue(file.ContentType ?? "application/octet-stream");

                    formData.Add(fileStreamContent, "file", file.FileName);

                    // ✅ Corrected endpoint
                    string apiUrl = "https://localhost:7114/api/Auth/UploadProfileImage";

                    var response = await client.PostAsync(apiUrl, formData);

                    if (response.IsSuccessStatusCode)
                    {
                        var apiResponse = await response.Content.ReadAsStringAsync();
                        return Content(apiResponse, "application/json");
                    }
                    else
                    {
                        var errorMsg = await response.Content.ReadAsStringAsync();
                        return Json(new { success = false, message = $"API Error: {errorMsg}" });
                    }
                }
            }
        }
        catch (Exception ex)
        {
            return Json(new { success = false, message = "Error: " + ex.Message });
        }
    }


    [HttpPost]
    public async Task<IActionResult> AddMedicalRecord(MedicalRecordModel model, IFormFile file)
    {
        if (file == null || file.Length == 0)
            return Json(new { success = false, message = "Please select a file." });

        try
        {
            using (var client = new HttpClient())
            using (var formData = new MultipartFormDataContent())
            {
                // Use safe conversions for nullable fields
                formData.Add(new StringContent(model.Id.ToString() ?? "0"), "Id");
                formData.Add(new StringContent(model.UserId.ToString() ?? "0"), "UserId");
                formData.Add(new StringContent(model.FileType ?? ""), "FileType");
                formData.Add(new StringContent(model.FileName ?? file.FileName), "FileName");
                formData.Add(new StringContent(model.FilePath ?? ""), "FilePath");
                formData.Add(new StringContent(model.CreatedDate == default ? DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") : model.CreatedDate.ToString("yyyy-MM-dd HH:mm:ss")), "CreatedDate");
                formData.Add(new StringContent(model.CreatedBy ?? "System"), "CreatedBy");

                // File content
                var fileContent = new StreamContent(file.OpenReadStream());
                fileContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("multipart/form-data");
                formData.Add(fileContent, "file", file.FileName);

                string apiUrl = "https://localhost:7114/api/Auth/AddMedicalRecord";
                var response = await client.PostAsync(apiUrl, formData);
                var jsonResponse = await response.Content.ReadAsStringAsync();
                var result = JsonConvert.DeserializeObject<dynamic>(jsonResponse);

                if (result.success == true)
                {
                    return Json(new
                    {
                        success = true,
                        message = result.message.ToString(),
                        alertType = "success"
                    });
                }
                else
                {
                    return Json(new
                    {
                        success = false,
                        message = result.message.ToString(),
                        alertType = "danger"
                    });
                }

            }
        }
        catch (Exception ex)
        {
            return Json(new { success = false, message = "Error: " + ex.Message });
        }
    }


 
    [HttpPost]
    public async Task<IActionResult> ViewMedicalRecord(int recordId)
    {
        try
        {
            using (var client = new HttpClient())
            {
                // Same as your curl URL
                string apiUrl = $"https://localhost:7114/api/Auth/GetMedicalRecordsByUser/{recordId}";
                client.DefaultRequestHeaders.Add("accept", "*/*");

                // Send GET request
                var response = await client.GetAsync(apiUrl);

                if (!response.IsSuccessStatusCode)
                {
                    return Content("❌ Failed to fetch medical records.");
                }

                var jsonData = await response.Content.ReadAsStringAsync();

                // ✅ Deserialize correctly
                var apiResponse = JsonConvert.DeserializeObject<ApiResponse<List<MedicalRecordModel1>>>(jsonData);
                var records = apiResponse.data;

                // Send to view
                return Json(new { success = true, data = records });
            }
        }
        catch (Exception ex)
        {
            return Content($"⚠️ Error: {ex.Message}");
        }
    }


    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
