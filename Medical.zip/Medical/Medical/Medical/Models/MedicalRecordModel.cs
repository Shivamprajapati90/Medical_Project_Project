﻿namespace Medical.Models
{
    public class MedicalRecordModel
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public string FileType { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }

    }
    public class ApiResponse<T>
    {
        public bool success { get; set; }
        public T data { get; set; }
        public string message { get; set; }
    }
    public class MedicalRecordModel1
    {
        public int RecordId { get; set; }
        public int UserId { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public string FileData { get; set; }
        public DateTime CreatedDate { get; set; }

    }
}
